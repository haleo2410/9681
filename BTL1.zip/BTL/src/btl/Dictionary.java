package btl;

import java.util.ArrayList;

    public class Dictionary {
        //khở tạo 1 danh sách mảng động lưu trữ các phần tử Word
    private  ArrayList<Word> word = new ArrayList();
    
//    public void Init(){
//        word = new ArrayList<>();
//    }
    
    
    public ArrayList<Word> getWord() {
        return word;
    }

    public void setWord(ArrayList<Word> word) {
        this.word = word;
    }   

    
}
    

