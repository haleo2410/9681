package dictionarygraphic;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import dictionarymanagement.DictionaryManagement;


public class DictPanel extends JPanel implements ActionListener{
	
	private DictionaryManagement s = new DictionaryManagement();
	private static final long serialVersionUID = 1L;
	private JTextField searchfield;
	private JTextArea meaningarea;
	private JTextArea historyarea;
	private JTextArea lovewordarea;
	private JButton click;
	private JButton speakword;
	private JButton deleteword;
	private JButton replaceword;
	private JButton likeword;
	
	
	
	public DictPanel() {
		setLayout(null);
		initPanel();
		initSearchingBox();
	}
	
	private void initPanel() {
		
		setPreferredSize(new Dimension(650, 550)); //cai dat size cho Panel
		this.setBackground(new Color(200,200,250));
	}

	public void readFile() {
		s.insertFromFile();
	}
	
	private void initSearchingBox() {
		
		//ImageIcon imageicon = new ImageIcon ();
		searchfield = new JTextField(30);
		meaningarea = new JTextArea(5,30);
		historyarea = new JTextArea(5,30);
		lovewordarea = new JTextArea(5,30);
		click = new JButton("Search");
		replaceword = new JButton("R");
		speakword = new JButton(new ImageIcon("C:/Users/user/Documents/OOP/dictionary/speaker2.png"));
		deleteword = new JButton("X");
		likeword = new JButton("L");
		
		searchfield.addActionListener(this);
		searchfield.setBounds(10,87,300,36);
		
		meaningarea.setBounds(10,190,420,360);
		meaningarea.setEditable(false);
		meaningarea.setLineWrap(true);
		meaningarea.setWrapStyleWord(true);
		meaningarea.setBackground(new Color(140,240,250));
		
		historyarea.setBounds(460,190,190,200);
		historyarea.setEditable(false);
		historyarea.setBackground(new Color(140,100,100));
		
		lovewordarea.setBounds(460,420,190,130);
		lovewordarea.setEditable(false);
		lovewordarea.setBackground(new Color(140,120,100));
		
		click.addActionListener(this);
		click.setBounds(310,85,100,40);
		
		speakword.addActionListener(this);
		speakword.setBounds(10,130,40,35);
		
		deleteword.setBounds(65,130,40,35);
		deleteword.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
            	deletedActionPerformed(evt);
            }
		});
		
		replaceword.addActionListener(this);
		replaceword.setBounds(115,130,40,35);
		
		likeword.setBounds(165,130,40,35);
		
		add(searchfield);
		add(meaningarea);
		add(historyarea);
		add(lovewordarea);
		add(click);
		add(replaceword);
		add(speakword);
		add(deleteword);
		add(likeword);
	}

	public void deletedActionPerformed(ActionEvent evt) {
        Icon icon = null;
        int exit =  JOptionPane.showConfirmDialog(getRootPane(), "bạn có muốn xóa từ? ","Thông báo!",JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE, icon);
        if(exit == JOptionPane.YES_OPTION){  
        	String searchword = searchfield.getText().toLowerCase();;
			try {
				s.dictionaryLookuptoDelete(searchword);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
        }
	}
       
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == searchfield || e.getSource() == click) {
			String searchword = searchfield.getText();
			String searchword1 = searchword.toLowerCase();
			meaningarea.setText(s.dictionaryLookup(searchword1));
			historyarea.setText(searchword + "\n" + historyarea.getText());
		}
		
		if(e.getSource() == replaceword) {
			searchfield.setEditable(meaningarea.isEditable());
			click.setEnabled(meaningarea.isEditable());
			speakword.setEnabled(meaningarea.isEditable());
			deleteword.setEnabled(meaningarea.isEditable());
			likeword.setEnabled(meaningarea.isEditable());
			meaningarea.setEditable(!meaningarea.isEditable());
			
			if(!meaningarea.isEditable()) {
				String newword = meaningarea.getText();
				String h = searchfield.getText().toLowerCase();
				if(!newword.equals("") && !h.equals("") ) {
					s.dictionaryLookuptoReplace(newword, h);
					try {
						s.dictionaryExpertToFile();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
			}
		}
		
		/*if(e.getSource() == deleteword) {
			String searchword = searchfield.getText();
			try {
				s.dictionaryLookuptoDelete(searchword);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}*/
		
		if(e.getSource() == speakword) {
			String searchword = searchfield.getText();
			if(!searchword.equals(""))
				s.Speech(searchword);
		}
	}

	private Image loadImage (String path) { //lay hinh anh tu path(duong dan)
		ImageIcon imageicon = new ImageIcon (path);
		Image newImage = imageicon.getImage();
		return newImage;
	}
	
}
