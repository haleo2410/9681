package btl;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Nguyen Ba Duc
 */
public class DictionaryManagement {
    private Dictionary dictionary = new Dictionary();

    public Dictionary getDictionary() {
        return dictionary;
    }

    public void setDictionary(Dictionary dictionary) {
        this.dictionary = dictionary;
    }
    
    Scanner input = new Scanner(System.in);
    
    // Hàm nhập n từ mới và thêm vào danh sách (Nhập từ mới và nghĩa của nó)
    public void insertFromCommandline(){
            
//            int n = input.nextInt();
//            for(int i = 0; i < n;i++){
//                System.out.println("Nhap tu can them: ");
//                String s_wordtarget = input.nextLine();
//                System.out.println("Nhap nghia tuong ung: ");
//                String s_wordexplain = input.nextLine();
//                Word w = new Word(s_wordtarget,s_wordexplain);
//                this.getDictionary().getWord().add(w);
//            }
    }
    
    // Đọc dữ liệu từ file
    public void insertFromFile() throws IOException {  
            
        try {
            InputStream in;
            in = new FileInputStream("Dictionaries.txt");
             Reader r = new InputStreamReader(in,"UTF-8");
             
        try (BufferedReader reader = new BufferedReader(r)) {
            String line;
            while((line = reader.readLine()) != null){
                String[] words = line.split("\\t");
                Word w = new Word();
                w.setWord_target(words[0]);
                w.setWord_explain(words[1]);
                this.getDictionary().getWord().add(w);
            }
            reader.close();
        }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(DictionaryManagement.class.getName()).log(Level.SEVERE, null, ex);
        }
           
    }
    
     // Hàm xuất danh sách ra file
    public void dictionaryExportToFile() throws IOException{
        File outFile = new File("List.txt");
        FileWriter fw = new FileWriter(outFile,false);
        try (BufferedWriter bfw = new BufferedWriter(fw)) {
            for (Word word : dictionary.getWord()) {
                {
                    bfw.write(word.toString() + "\r\n");
                }  
            }
        }
    }
    
    
    
    // Tìm một từ có trong từ điển và trả về nghĩa của nó
    public String dictionaryLookup(String word_lookup){
       for(int i = 0; i < this.dictionary.getWord().size(); i++){
           if(this.getDictionary().getWord().get(i).getWord_target().equals(word_lookup)) {
              return this.getDictionary().getWord().get(i).getWord_explain();
            }
        }
        return "Khong tim thay!";
    }
    
    // Thêm một từ nhập vào từ bàn phím (thêm vào file)
    public void addWord(String s_wordtarget,String s_wordexplain ) throws IOException{
        //System.out.println("Nhap tu can them: ");
        //String s_wordtarget = input.nextLine();
        //System.out.println("Nhap nghia tuong ung: ");
        //String s_wordexplain = input.nextLine();
        //Word w = new Word(s_wordtarget,s_wordexplain);
//        File outFile = new File("Dictionaries.txt");
//        FileWriter fw = new FileWriter(outFile,true);
//        try (BufferedWriter bfw = new BufferedWriter(fw)) {
//            bfw.write ("\r\n" + w.toString());
//            bfw.close();
//        }    
    }
    
    // Xóa một từ khỏi danh sách
    public void deleteWord(String s) throws IOException {
        //System.out.println("Nhap tu can xoa: ");
        //String s = input.nextLine();
        for(int i = 0;i < this.getDictionary().getWord().size();i++){
            if(s.equals(this.getDictionary().getWord().get(i).getWord_target())){
                this.getDictionary().getWord().remove(i);
            }
        }
        this.dictionaryExportToFile();
    }
    
    // Sap xep tu
     public void sortWord(){
        for (int i = 0;i < this.getDictionary().getWord().size();i++){
            for(int j = i+1;j < this.getDictionary().getWord().size();j++){
                if(this.getDictionary().getWord().get(j).getWord_target().compareTo(dictionary.getWord().get(i).getWord_target()) < 0){
                    Word temp = this.getDictionary().getWord().get(i);
                    this.getDictionary().getWord().set(i,this.getDictionary().getWord().get(j));
                    this.getDictionary().getWord().set(j,temp);
                }
            }
        }
    }
     
    
}